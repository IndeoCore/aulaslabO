#include <iostream>
#include <string>

using namespace std;

void teste1();
void teste2();
void teste3();

int main(){
    teste3(); // Escolha o teste do exercicio a ser testado
    cout << "Passei aqui" << endl;
    return 0;
}
